import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // basePath: "/gis-in-next",
  // output: "export",  // <=== enables static exports
  // reactStrictMode: true,
};

export default nextConfig;
