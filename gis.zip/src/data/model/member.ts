export default interface Member{
    id: number
    name: string
    description: string
    image: string
}