(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_23f34f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_23f34f._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_117c92._.js",
    "static/chunks/src_253b80._.js"
  ],
  "source": "dynamic"
});
