__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root of the server]__f81d50._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_beb007._.js",
  "static/chunks/[root of the server]__f265a1._.js",
  "static/chunks/pages__app_5771e1._.js",
  "static/chunks/pages__app_f2320d._.js"
])
